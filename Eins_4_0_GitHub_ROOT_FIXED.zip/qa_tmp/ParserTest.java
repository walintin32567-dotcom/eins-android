import de.eins.one.SmartParser;
import java.time.LocalDate;
public class ParserTest {
 static int count=0;
 static void expect(String text,String lang,String title,String date,String time,String repeat){
    SmartParser p=SmartParser.parse(text,lang,LocalDate.of(2026,9,17));
    if(!p.title.equals(title)||!(date==null?p.date==null:date.equals(p.date))||!(time==null?p.time==null:time.equals(p.time))||!repeat.equals(p.repeat))
      throw new AssertionError(text+" => "+p.title+" | "+p.date+" | "+p.time+" | "+p.repeat);
    System.out.println("PASS parser " + (++count) + " / " + lang + " / " + text);
 }
 public static void main(String[] args){
  expect("Morgen um 9 Milch kaufen","de","Milch kaufen","2026-09-18","09:00","none");
  expect("Tomorrow at 18:30 buy milk","en","buy milk","2026-09-18","18:30","none");
  expect("Завтра о 9 купити молоко","uk","купити молоко","2026-09-18","09:00","none");
  expect("yarın saat 09:30 süt al","tr","süt al","2026-09-18","09:30","none");
  expect("غدا 09:20 شراء الحليب","ar","شراء الحليب","2026-09-18","09:20","none");
  expect("jutro o 9 kupić mleko","pl","kupić mleko","2026-09-18","09:00","none");
  expect("mâine la 9 cumpără lapte","ro","cumpără lapte","2026-09-18","09:00","none");
  expect("domani alle 9 comprare latte","it","comprare latte","2026-09-18","09:00","none");
  expect("demain à 9 acheter du lait","fr","acheter du lait","2026-09-18","09:00","none");
  expect("mañana a las 9 comprar leche","es","comprar leche","2026-09-18","09:00","none");
  expect("jeden Tag um 18:00 Wasser trinken","de","Wasser trinken","2026-09-17","18:00","daily");
  expect("Every week at 18:00 shop","en","shop","2026-09-17","18:00","weekly");
  expect("щомісяця 18:00 заплатити","uk","заплатити","2026-09-17","18:00","monthly");
  expect("Am 31.02.2027 erinnern","de","Am 31.02.2027 erinnern",null,null,"none");
  expect("2026-12-31 23:59 party","en","party","2026-12-31","23:59","none");
  expect("Pay bill","en","Pay bill",null,null,"none");
  System.out.println("TOTAL PARSER TESTS: "+count);
 }
}
