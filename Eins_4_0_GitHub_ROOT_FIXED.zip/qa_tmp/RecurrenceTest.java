import java.time.LocalDate;
import de.eins.one.Recurrence;
public class RecurrenceTest {
 static int tests=0;
 static void check(String due,String done,String repeat,String expected){
  LocalDate r=Recurrence.next(LocalDate.parse(due),LocalDate.parse(done),repeat);
  if(!r.toString().equals(expected))throw new AssertionError(due+" "+repeat+" => "+r+" expected "+expected);
  System.out.println("PASS recurrence " + (++tests) + " / " + repeat + " / " + expected);
 }
 public static void main(String[] args){
  check("2026-09-17","2026-09-17","daily","2026-09-18");
  check("2026-09-17","2026-09-18","daily","2026-09-19");
  check("2026-09-17","2026-10-01","weekly","2026-10-08");
  check("2026-01-31","2026-01-31","monthly","2026-02-28");
  check("2026-01-31","2026-02-28","monthly","2026-03-31");
  check("2024-01-31","2024-02-29","monthly","2024-03-31");
  check("2026-09-20","2026-09-17","weekly","2026-09-27");
  check("2020-01-01","2026-09-17","daily","2026-09-18");
  System.out.println("TOTAL RECURRENCE TESTS: "+tests);
 }
}
