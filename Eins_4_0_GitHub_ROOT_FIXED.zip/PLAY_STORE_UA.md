# Eins. — налаштування платного запуску в Google Play

**Модель:** одноразова оплата 3,99 € у Німеччині, без внутрішніх покупок, передплат, рекламних SDK. **Ціна НЕ встановлюється у Gradle, APK чи вихідному коді.** Її виставляє власник акаунту Play Console у `Produkte → App-Preise`. Комісія платформи та податки відраховуються від надходжень. Не публікуйте застосунок як безкоштовний, якщо має залишатися платним.

**Німецька назва:** Eins. – Aufgaben ohne Internet.

**Короткий опис (DE):** Aufgaben, die bleiben. Drei Widgets, Erinnerungen und kein Abo – komplett offline.

**Повний опис (DE, чернетка):**

> Eins. hilft dir, eine Sache nach der anderen zu erledigen. Schreibe eine Aufgabe auf, sieh sie direkt auf dem Startbildschirm und lass dich auf deinem Gerät erinnern. Drei Widgets für eine, drei oder fünf Aufgaben. Wiederholungen, optionale Offline-Spracheingabe auf unterstützten Android-Geräten und passwortgeschützte Sicherungen. Ohne Konto, ohne Werbung und ohne Abo. Einmal zahlen, lokal nutzen. Für sehr genaue Erinnerungen können zusätzliche Android-Berechtigungen erforderlich sein.

**Перед запуском перевірити:** унікальність пакета, право на назву та іконку, цільова версія Android за актуальною політикою, декларування exact alarm і мікрофона, актуальна політика конфіденційності, Data safety, скриншоти **справжнього APK**, відсутність неперевірених рекламних обіцянок, тест 12+ користувачів/14 днів якщо застосовується до типу облікового запису (перевірити поточні правила). Після тесту налаштувати paid pricing, підписання та публікацію в акаунті власника.

**Офіційні джерела:**
- https://support.google.com/googleplay/android-developer/answer/6334373?hl=de
- https://developer.android.com/develop/background-work/services/alarms
- https://developer.android.com/develop/ui/views/appwidgets/overview
