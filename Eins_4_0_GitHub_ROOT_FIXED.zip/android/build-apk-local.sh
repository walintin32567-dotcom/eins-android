#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo 'Потрібні: Android SDK Platform 36, JDK 17, Gradle 8.13.'
gradle --no-daemon :app:assembleDebug
printf '\nAPK: %s\n' "$(pwd)/app/build/outputs/apk/debug/app-debug.apk"
