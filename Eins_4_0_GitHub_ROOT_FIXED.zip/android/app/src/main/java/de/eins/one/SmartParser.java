package de.eins.one;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Deterministic local parser: proposes a plan, never saves or mutates data itself. */
public final class SmartParser {
    public final String title,date,time,repeat;
    public final boolean detected;
    private SmartParser(String s,String d,String t,String r,boolean found){title=s;date=d;time=t;repeat=r;detected=found;}
    private static final Pattern ISO=Pattern.compile("(?<!\\d)(20\\d{2})-(0?[1-9]|1[0-2])-(0?[1-9]|[12]\\d|3[01])(?!\\d)");
    private static final Pattern EU=Pattern.compile("(?<!\\d)(0?[1-9]|[12]\\d|3[01])\\.(0?[1-9]|1[0-2])\\.(20\\d{2})(?!\\d)");
    private static final Pattern CLOCK=Pattern.compile("(?i)(?<!\\d)(?:um\\s+|at\\s+|о\\s+|об\\s+|saat\\s+|o\\s+|à\\s+|a\\s+|alle\\s+)?([01]?\\d|2[0-3])[:.]([0-5]\\d)(?!\\d)");
    private static final Pattern HOUR=Pattern.compile("(?i)(?<!\\p{L})(?:um|at|о|об|o|saat|alle|à|la|a\\s+las)\\s+([01]?\\d|2[0-3])(?:\\s*(?:uhr|годині|год))?(?!\\d)");
    private static final String[] TODAY={"heute","today","сьогодні","bugün","اليوم","dzisiaj","astăzi","oggi","aujourd'hui","hoy"};
    private static final String[] TOMORROW={"morgen","tomorrow","завтра","yarın","غدا","jutro","mâine","domani","demain","mañana"};
    private static final String[] LANG={"de","en","uk","tr","ar","pl","ro","it","fr","es"};
    private static final String[] DAILY={"täglich","jeden tag","every day","daily","щодня","кожного дня","her gün","يوميا","codziennie","zilnic","ogni giorno","tous les jours","cada día","cada dia"};
    private static final String[] WEEKLY={"wöchentlich","jede woche","every week","weekly","щотижня","her hafta","أسبوعيا","co tydzień","săptămânal","ogni settimana","chaque semaine","cada semana"};
    private static final String[] MONTHLY={"monatlich","jeden monat","every month","monthly","щомісяця","her ay","شهريا","co miesiąc","lunar","ogni mese","chaque mois","cada mes"};
    private static String removeWord(String text,String phrase){return text.replaceAll("(?iu)(?<!\\p{L})"+Pattern.quote(phrase)+"(?!\\p{L})"," ");}
    public static SmartParser parse(String input,String language,LocalDate now){
        if(input==null)return new SmartParser("",null,null,"none",false);
        String text=input.trim(),date=null,time=null,repeat="none";boolean found=false;
        Matcher m=ISO.matcher(text);
        if(m.find())try{date=LocalDate.of(Integer.parseInt(m.group(1)),Integer.parseInt(m.group(2)),Integer.parseInt(m.group(3))).toString();text=text.substring(0,m.start())+" "+text.substring(m.end());found=true;}catch(Exception ignored){}
        if(date==null){m=EU.matcher(text);if(m.find())try{date=LocalDate.of(Integer.parseInt(m.group(3)),Integer.parseInt(m.group(2)),Integer.parseInt(m.group(1))).toString();text=text.substring(0,m.start())+" "+text.substring(m.end());found=true;}catch(Exception ignored){}}
        m=CLOCK.matcher(text);if(m.find())try{time=LocalTime.of(Integer.parseInt(m.group(1)),Integer.parseInt(m.group(2))).format(DateTimeFormatter.ofPattern("HH:mm"));text=text.substring(0,m.start())+" "+text.substring(m.end());found=true;}catch(Exception ignored){}
        if(time==null){m=HOUR.matcher(text);if(m.find())try{time=LocalTime.of(Integer.parseInt(m.group(1)),0).format(DateTimeFormatter.ofPattern("HH:mm"));text=text.substring(0,m.start())+" "+text.substring(m.end());found=true;}catch(Exception ignored){}}
        // Preserve words if date was explicitly specified; otherwise natural relative dates.
        for(int i=0;i<LANG.length;i++){
            String key=LANG[i];if(!language.equals(key)&&!"system".equals(language))continue;
            if(date==null&&text.toLowerCase(Locale.ROOT).contains(TOMORROW[i])){String stripped=removeWord(text,TOMORROW[i]);if(!stripped.equals(text)){text=stripped;date=now.plusDays(1).toString();found=true;}}
            if(date==null&&text.toLowerCase(Locale.ROOT).contains(TODAY[i])){String stripped=removeWord(text,TODAY[i]);if(!stripped.equals(text)){text=stripped;date=now.toString();found=true;}}
        }
        for(String word:DAILY){String stripped=removeWord(text,word);if(!stripped.equals(text)){repeat="daily";text=stripped;found=true;break;}}
        if("none".equals(repeat))for(String word:WEEKLY){String stripped=removeWord(text,word);if(!stripped.equals(text)){repeat="weekly";text=stripped;found=true;break;}}
        if("none".equals(repeat))for(String word:MONTHLY){String stripped=removeWord(text,word);if(!stripped.equals(text)){repeat="monthly";text=stripped;found=true;break;}}
        if(date==null&&(!"none".equals(repeat)||time!=null)){date=now.toString();found=true;}
        text=text.replaceAll("\\s+"," ").trim();
        if(text.isEmpty())return new SmartParser(input.trim(),null,null,"none",false);
        return new SmartParser(text,date,time,repeat,found);
    }
}
