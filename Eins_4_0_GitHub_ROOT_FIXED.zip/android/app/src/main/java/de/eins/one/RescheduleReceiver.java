package de.eins.one;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
/** Refresh alarms after reboot, timezone/clock changes and exact-alarm permission changes. */
public final class RescheduleReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){ReminderScheduler.sync(c);OneWidget.refresh(c);}
}
