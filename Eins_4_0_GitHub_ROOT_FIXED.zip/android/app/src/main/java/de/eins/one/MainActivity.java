package de.eins.one;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import android.net.Uri;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONException;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Arrays;

/** Offline task UI. No WebView bridge, account, third-party SDK or network permission. */
public final class MainActivity extends Activity {
    private static final int EXPORT=101,IMPORT=102;
    private static final int GREEN=Color.rgb(30,97,78), INK=Color.rgb(26,43,33), BG=Color.rgb(247,246,242);
    private EditText input;
    private TextView spotlight,summary;
    private LinearLayout taskBox;
    private String selectedDate=LocalDate.now().toString();
    private String selectedTime=null;
    private String filter="today";
    private boolean priority=false;
    private Button todayBtn,tomorrowBtn,laterBtn,dateBtn,starBtn,timeBtn,repeatBtn;
    private String selectedRepeat="none";
    private SpeechRecognizer speech;
    private boolean encryptedExport=false;
    private char[] exportPassword=null;

    @Override protected void attachBaseContext(Context base){
        String lang=TaskStore.language(base);
        if(!"system".equals(lang)){
            Configuration conf=new Configuration(base.getResources().getConfiguration());conf.setLocale(Locale.forLanguageTag(lang));
            base=base.createConfigurationContext(conf);
        }
        super.attachBaseContext(base);
    }
    @Override protected void onCreate(Bundle state){super.onCreate(state);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        ReminderScheduler.channel(this);ReminderScheduler.sync(this);draw();captureSharedText(getIntent());if(getIntent().getBooleanExtra("focus_add",false))focusInput();
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);captureSharedText(intent);
        if(intent.getBooleanExtra("focus_add",false))focusInput();}
    @Override protected void onResume(){super.onResume();if(taskBox!=null)refresh();}
    private void captureSharedText(Intent intent){
        if(Intent.ACTION_SEND.equals(intent.getAction())&&"text/plain".equals(intent.getType())){
            CharSequence value=intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if(value!=null&&input!=null){String s=value.toString().trim();input.setText(s.substring(0,Math.min(s.length(),180)));input.setSelection(input.length());focusInput();}
        }
    }
    private void focusInput(){input.requestFocus();input.postDelayed(()->{
        InputMethodManager imm=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
        if(imm!=null)imm.showSoftInput(input,InputMethodManager.SHOW_IMPLICIT);
    },180);}
    private int px(float dp){return (int)(dp*getResources().getDisplayMetrics().density+.5f);}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView text(String s,int sp,boolean bold,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private GradientDrawable card(boolean green){GradientDrawable g=new GradientDrawable();g.setColor(green?GREEN:Color.WHITE);g.setCornerRadius(px(19));return g;}
    private Button button(String label){Button b=new Button(this);b.setAllCaps(false);b.setText(label);b.setTextSize(13);b.setTextColor(INK);b.setMinHeight(px(48));return b;}
    private void gap(LinearLayout l,int dp){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,px(dp)));}
    private void toast(int msg){Toast.makeText(this,msg,Toast.LENGTH_LONG).show();}
    private void draw(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        LinearLayout all=vertical();all.setPadding(px(18),px(16),px(18),px(50));scroll.addView(all);setContentView(scroll);
        LinearLayout header=horizontal();TextView brand=text(getString(R.string.app_name),24,true,GREEN);
        header.addView(brand,new LinearLayout.LayoutParams(0,px(55),1));
        Button language=button("🌐");language.setContentDescription(getString(R.string.language));
        language.setOnClickListener(v->chooseLanguage());header.addView(language,new LinearLayout.LayoutParams(px(54),px(52)));
        Button settings=button("⋮");settings.setContentDescription(getString(R.string.settings));
        settings.setOnClickListener(v->settings());header.addView(settings,new LinearLayout.LayoutParams(px(50),px(52)));
        all.addView(header);gap(all,25);
        all.addView(text(getString(R.string.headline),29,true,INK));gap(all,10);
        all.addView(text(getString(R.string.capture_label),14,false,INK));gap(all,8);
        LinearLayout entry=horizontal();input=new EditText(this);input.setSingleLine(true);input.setTextSize(17);
        input.setHint(R.string.placeholder);input.setMaxLines(1);input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        entry.addView(input,new LinearLayout.LayoutParams(0,px(58),1));
        Button add=button("+  "+getString(R.string.add));add.setTextColor(Color.WHITE);add.setBackground(card(true));
        add.setOnClickListener(v->add());entry.addView(add,new LinearLayout.LayoutParams(px(92),px(54)));
        all.addView(entry);gap(all,9);
        // Offline voice is shown ONLY when Android has a dedicated on-device recognizer.
        if(Build.VERSION.SDK_INT>=31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)){
            Button voice=button("🎙  "+getString(R.string.voice));voice.setContentDescription(getString(R.string.voice));
            voice.setOnClickListener(v->startVoice());all.addView(voice,new LinearLayout.LayoutParams(-1,px(48)));
        }
        LinearLayout dates=horizontal();todayBtn=button(getString(R.string.today));tomorrowBtn=button(getString(R.string.tomorrow));
        laterBtn=button(getString(R.string.anytime));dateBtn=button(getString(R.string.choose_date));
        for(Button b:new Button[]{todayBtn,tomorrowBtn,laterBtn,dateBtn}){
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,px(48),1);dates.addView(b,lp);
        }
        todayBtn.setOnClickListener(v->select("today"));tomorrowBtn.setOnClickListener(v->select("tomorrow"));
        laterBtn.setOnClickListener(v->select("later"));dateBtn.setOnClickListener(v->pickDate());
        all.addView(dates);
        starBtn=button("☆ "+getString(R.string.important));starBtn.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        starBtn.setOnClickListener(v->{priority=!priority;starBtn.setText((priority?"★ ":"☆ ")+getString(R.string.important));});
        all.addView(starBtn,new LinearLayout.LayoutParams(-1,px(45)));
        LinearLayout extras=horizontal();timeBtn=button(getString(R.string.choose_time));repeatBtn=button(getString(R.string.repeat_none));
        timeBtn.setOnClickListener(v->pickTime());repeatBtn.setOnClickListener(v->chooseRepeat());
        extras.addView(timeBtn,new LinearLayout.LayoutParams(0,px(48),1));
        extras.addView(repeatBtn,new LinearLayout.LayoutParams(0,px(48),1));all.addView(extras);
        all.addView(text(getString(R.string.smart_hint),12,false,Color.DKGRAY));gap(all,12);
        all.addView(text(getString(R.string.privacy),12,false,Color.DKGRAY));gap(all,26);
        all.addView(text(getString(R.string.next),15,true,GREEN));gap(all,8);
        spotlight=text("",21,true,Color.WHITE);spotlight.setGravity(Gravity.CENTER_VERTICAL);
        spotlight.setPadding(px(18),px(17),px(18),px(17));spotlight.setMinHeight(px(105));spotlight.setBackground(card(true));
        spotlight.setOnClickListener(v->showNext());all.addView(spotlight);gap(all,26);
        summary=text("",20,true,INK);all.addView(summary);gap(all,12);
        LinearLayout tabs=horizontal();String[] names={getString(R.string.today),getString(R.string.later),getString(R.string.all),getString(R.string.done)};
        String[] types={"today","later","all","done"};
        for(int i=0;i<4;i++){
            final String f=types[i];Button tab=button(names[i]);tab.setOnClickListener(v->{filter=f;refresh();});
            tabs.addView(tab,new LinearLayout.LayoutParams(0,px(48),1));
        }
        all.addView(tabs);gap(all,13);
        taskBox=vertical();all.addView(taskBox);select("today");refresh();
    }
    private void select(String mode){
        if("today".equals(mode))selectedDate=LocalDate.now().toString();
        else if("tomorrow".equals(mode))selectedDate=LocalDate.now().plusDays(1).toString();
        else if("later".equals(mode))selectedDate=null;
        selectedTime=null;updateTimeLabel();
        todayBtn.setText(("today".equals(mode)?"● ":"")+getString(R.string.today));
        tomorrowBtn.setText(("tomorrow".equals(mode)?"● ":"")+getString(R.string.tomorrow));
        laterBtn.setText(("later".equals(mode)?"● ":"")+getString(R.string.anytime));
        dateBtn.setText("custom".equals(mode)?"● "+selectedDate:getString(R.string.choose_date));
    }
    private void pickDate(){
        LocalDate d=LocalDate.now();new DatePickerDialog(this,(picker,y,m,day)->{
            selectedDate=LocalDate.of(y,m+1,day).toString();selectedTime=null;updateTimeLabel();
            todayBtn.setText(getString(R.string.today));tomorrowBtn.setText(getString(R.string.tomorrow));laterBtn.setText(getString(R.string.anytime));
            dateBtn.setText("● "+selectedDate);
        },d.getYear(),d.getMonthValue()-1,d.getDayOfMonth()).show();
    }
    private void pickTime(){java.time.LocalTime now=java.time.LocalTime.now();new TimePickerDialog(this,(view,h,m)->{
        selectedTime=String.format(Locale.ROOT,"%02d:%02d",h,m);updateTimeLabel();
        if(selectedDate==null){selectedDate=LocalDate.now().toString();dateBtn.setText("● "+selectedDate);}
    },now.getHour(),now.getMinute(),true).show();}
    private void updateTimeLabel(){if(timeBtn!=null)timeBtn.setText(selectedTime==null?getString(R.string.choose_time):"⏰ "+selectedTime);}
    private void chooseRepeat(){String[] codes={"none","daily","weekly","monthly"};String[] labels={getString(R.string.repeat_none),getString(R.string.repeat_daily),getString(R.string.repeat_weekly),getString(R.string.repeat_monthly)};
        new AlertDialog.Builder(this).setTitle(R.string.repeat_label).setSingleChoiceItems(labels,Arrays.asList(codes).indexOf(selectedRepeat),(dialog,index)->{
            selectedRepeat=codes[index];repeatBtn.setText(labels[index]);
            if(selectedDate==null&&!"none".equals(selectedRepeat)){selectedDate=LocalDate.now().toString();dateBtn.setText("● "+selectedDate);}
            dialog.dismiss();}).setNegativeButton(R.string.cancel,null).show();}
    private void add(){String typed=input.getText().toString().trim();if(typed.isEmpty()){input.setError(getString(R.string.capture_label));return;}
        String language=TaskStore.language(this);
        if("system".equals(language))language=getResources().getConfiguration().getLocales().get(0).getLanguage();
        SmartParser parsed=SmartParser.parse(typed,language,LocalDate.now());
        if(parsed.detected && parsed.title.length()<=180){
            String dt=parsed.date!=null?parsed.date:selectedDate,tm=parsed.time!=null?parsed.time:selectedTime;
            String recurrence=!"none".equals(parsed.repeat)?parsed.repeat:selectedRepeat;
            String recurrenceLabel="daily".equals(recurrence)?getString(R.string.repeat_daily):"weekly".equals(recurrence)?getString(R.string.repeat_weekly):"monthly".equals(recurrence)?getString(R.string.repeat_monthly):getString(R.string.repeat_none);
            String preview=parsed.title+"\n"+(dt==null?getString(R.string.no_date):dt)+"  "+(tm==null?"":tm)+"\n"+getString(R.string.repeat_label)+": "+recurrenceLabel;
            new AlertDialog.Builder(this).setTitle(R.string.smart_confirm).setMessage(preview)
                .setPositiveButton(R.string.save,(d,w)->saveTask(parsed.title,dt,tm,recurrence))
                .setNeutralButton(R.string.save_original,(d,w)->saveTask(typed,selectedDate,selectedTime,selectedRepeat))
                .setNegativeButton(R.string.cancel,null).show();
        }else saveTask(typed,selectedDate,selectedTime,selectedRepeat);
    }
    private void saveTask(String title,String date,String time,String recurrence){
        if(!TaskStore.add(this,title,date,time,priority,recurrence)){toast(R.string.not_saved);return;}
        input.setText("");priority=false;selectedRepeat="none";
        repeatBtn.setText(R.string.repeat_none);starBtn.setText("☆ "+getString(R.string.important));toast(R.string.added_toast);refresh();
        if(time!=null && Build.VERSION.SDK_INT>=33 && !ReminderScheduler.notificationsAllowed(this))
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},202);
    }
    private void startVoice(){
        if(Build.VERSION.SDK_INT<31||!SpeechRecognizer.isOnDeviceRecognitionAvailable(this)){toast(R.string.voice_unavailable);return;}
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},203);return;}
        if(speech!=null){speech.destroy();speech=null;}
        speech=SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
        speech.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle p){} public void onBeginningOfSpeech(){} public void onRmsChanged(float x){}
            public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){}
            public void onError(int e){toast(R.string.voice_unavailable);if(speech!=null){speech.destroy();speech=null;}}
            public void onResults(Bundle b){ArrayList<String> words=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if(words!=null&&!words.isEmpty()){String result=words.get(0);input.setText(result.substring(0,Math.min(180,result.length())));input.setSelection(input.length());}
                if(speech!=null){speech.destroy();speech=null;}}
            public void onPartialResults(Bundle b){} public void onEvent(int x,Bundle b){}
        });
        Intent request=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
          .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
          .putExtra(RecognizerIntent.EXTRA_LANGUAGE,getResources().getConfiguration().getLocales().get(0).toLanguageTag())
          .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true);
        speech.startListening(request);
    }
    @Override public void onRequestPermissionsResult(int request,String[] names,int[] grants){super.onRequestPermissionsResult(request,names,grants);
        if(request==203&&grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED)startVoice();
        if(request==202 && grants.length>0&&grants[0]!=PackageManager.PERMISSION_GRANTED)toast(R.string.permission_info);
    }
    @Override protected void onDestroy(){if(speech!=null){speech.destroy();speech=null;}super.onDestroy();}
    private boolean todayOrOverdue(TaskStore.Task t){return t.dueDate!=null&&t.dueDate.compareTo(LocalDate.now().toString())<=0;}
    private void refresh(){
        if(taskBox==null)return;TaskStore.Read read=TaskStore.read(this);taskBox.removeAllViews();
        if(read.corrupt){summary.setText(R.string.store_corrupt);spotlight.setText(R.string.store_corrupt);return;}
        List<TaskStore.Task> open=TaskStore.sortedOpen(this);spotlight.setText(open.isEmpty()?getString(R.string.widget_empty):open.get(0).text);
        summary.setText(getString(R.string.tasks_count,open.size()));
        List<TaskStore.Task> list=new ArrayList<>();
        for(TaskStore.Task t:read.tasks){
            if("done".equals(filter)){if(t.done)list.add(t);}
            else if(t.done)continue;
            else if("today".equals(filter)&&todayOrOverdue(t))list.add(t);
            else if("later".equals(filter)&&!todayOrOverdue(t))list.add(t);
            else if("all".equals(filter))list.add(t);
        }
        // Preserve the spotlight's ordering for open items; completed items are recent first.
        if("done".equals(filter))list.sort((a,b)->b.updatedAt.compareTo(a.updatedAt));
        else {List<TaskStore.Task> sorted=TaskStore.sortedOpen(this);java.util.Map<String,Integer> order=new java.util.HashMap<>();for(int i=0;i<sorted.size();i++)order.put(sorted.get(i).id,i);list.sort((a,b)->Integer.compare(order.get(a.id),order.get(b.id)));}
        if(list.isEmpty()){taskBox.addView(text(getString(R.string.empty_list),14,false,Color.DKGRAY));return;}
        for(TaskStore.Task task:list){
            LinearLayout row=horizontal();row.setPadding(px(9),px(8),px(6),px(8));row.setBackground(card(false));
            CheckBox done=new CheckBox(this);done.setChecked(task.done);done.setContentDescription(getString(R.string.widget_complete)+": "+task.text);
            done.setOnClickListener(v->{if(!TaskStore.toggle(this,task.id))toast(R.string.not_saved);refresh();});
            row.addView(done,new LinearLayout.LayoutParams(px(52),px(50)));
            String suffix=(task.dueDate==null?getString(R.string.no_date):task.dueDate+(task.dueTime==null?"":" · "+task.dueTime));
            TextView label=text(task.text+"\n"+suffix,16,false,INK);label.setMaxLines(3);label.setOnClickListener(v->editTask(task));
            row.addView(label,new LinearLayout.LayoutParams(0,px(68),1));
            Button edit=button("⋯");edit.setContentDescription(getString(R.string.edit_task)+": "+task.text);
            edit.setOnClickListener(v->editTask(task));row.addView(edit,new LinearLayout.LayoutParams(px(49),px(55)));
            taskBox.addView(row);gap(taskBox,9);
        }
    }
    private void showNext(){List<TaskStore.Task> list=TaskStore.sortedOpen(this);if(!list.isEmpty())editTask(list.get(0));else focusInput();}
    private EditText inputLine(String text,String hint){EditText e=new EditText(this);e.setText(text==null?"":text);e.setHint(hint);e.setTextSize(16);return e;}
    private void editTask(TaskStore.Task task){
        LinearLayout body=vertical();body.setPadding(px(20),px(3),px(20),px(2));
        EditText title=inputLine(task.text,getString(R.string.task_text));body.addView(title);
        EditText date=inputLine(task.dueDate,getString(R.string.date_hint));date.setSingleLine(true);
        body.addView(date);EditText time=inputLine(task.dueTime,getString(R.string.time_hint));time.setSingleLine(true);body.addView(time);
        CheckBox important=new CheckBox(this);important.setText(R.string.important);important.setChecked(task.priority);body.addView(important);
        android.widget.Spinner repeat=new android.widget.Spinner(this);
        String[] repeatItems={getString(R.string.repeat_none),getString(R.string.repeat_daily),getString(R.string.repeat_weekly),getString(R.string.repeat_monthly)};
        repeat.setAdapter(new android.widget.ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,repeatItems));
        repeat.setSelection(Math.max(0,Arrays.asList("none","daily","weekly","monthly").indexOf(task.repeat)));body.addView(repeat);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(R.string.edit_task).setView(body)
            .setPositiveButton(R.string.save,null).setNeutralButton(R.string.delete,(di,which)->{
                new AlertDialog.Builder(this).setMessage(R.string.delete_confirm)
                    .setPositiveButton(R.string.delete,(dialog,x)->{if(!TaskStore.delete(this,task.id))toast(R.string.not_saved);refresh();})
                    .setNegativeButton(R.string.cancel,null).show();
            }).setNegativeButton(R.string.cancel,null).create();
        d.setOnShowListener(v->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b->{
            String dt=date.getText().toString().trim(),tm=time.getText().toString().trim();
            boolean saved=TaskStore.update(this,task.id,title.getText().toString(),dt.isEmpty()?null:dt,tm.isEmpty()?null:tm,important.isChecked(),new String[]{"none","daily","weekly","monthly"}[repeat.getSelectedItemPosition()]);
            if(!saved){toast(R.string.not_saved);return;}d.dismiss();refresh();toast(R.string.saved_toast);
        }));d.show();
    }
    private void chooseLanguage(){
        String[] codes={"system","de","en","uk","tr","ar","pl","ro","it","fr","es"};
        String[] names={getString(R.string.system_language),"Deutsch","English","Українська","Türkçe","العربية","Polski","Română","Italiano","Français","Español"};
        new AlertDialog.Builder(this).setTitle(R.string.language).setItems(names,(d,index)->{
            if(TaskStore.setLanguage(this,codes[index])){OneWidget.refresh(this);recreate();}
            else toast(R.string.not_saved);
        }).show();
    }
    private void settings(){
        String[] opts={getString(R.string.export_backup),getString(R.string.export_encrypted),getString(R.string.import_backup),getString(R.string.language),getString(R.string.exact_alarm)};
        new AlertDialog.Builder(this).setTitle(R.string.settings)
            .setItems(opts,(d,index)->{
                if(index==0){encryptedExport=false;exportBackup();}
                else if(index==1)requestEncryptedExport();else if(index==2)importBackup();else if(index==3)chooseLanguage();else askExact();
            }).setNegativeButton(R.string.cancel,null).show();
    }
    private void askExact(){
        if(Build.VERSION.SDK_INT<31||ReminderScheduler.preciseAllowed(this)){toast(R.string.exact_already);return;}
        new AlertDialog.Builder(this).setMessage(R.string.exact_explain)
            .setPositiveButton(R.string.exact_alarm,(d,w)->{
                try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName())));}
                catch(Exception e){toast(R.string.permission_info);}
            }).setNegativeButton(R.string.cancel,null).show();
    }
    private void requestEncryptedExport(){
        LinearLayout fields=vertical();fields.setPadding(px(18),0,px(18),0);
        EditText pass=inputLine("",getString(R.string.password_hint));pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText verify=inputLine("",getString(R.string.confirm_password));verify.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        fields.addView(pass);fields.addView(verify);
        new AlertDialog.Builder(this).setTitle(R.string.export_encrypted).setView(fields)
          .setPositiveButton(R.string.export_backup,(d,w)->{
            char[] password=pass.getText().toString().toCharArray();
            char[] confirmation=verify.getText().toString().toCharArray();
            boolean okay=password.length>=8&&Arrays.equals(password,confirmation);
            Arrays.fill(confirmation,'\0');
            if(!okay){Arrays.fill(password,'\0');toast(R.string.password_check);return;}
            encryptedExport=true;exportPassword=password;exportBackup();
          }).setNegativeButton(R.string.cancel,null).show();
    }
    private void exportBackup(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");
        i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,"eins-"+(encryptedExport?"encrypted-":"backup-")+LocalDate.now()+".json");
        startActivityForResult(i,EXPORT);
    }
    private void importBackup(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,IMPORT);
    }
    @Override protected void onActivityResult(int code,int result,Intent data){super.onActivityResult(code,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null){
            if(code==EXPORT){if(exportPassword!=null){Arrays.fill(exportPassword,'\0');exportPassword=null;}encryptedExport=false;}
            return;
        }
        try{
            if(code==EXPORT){
                String json=TaskStore.backup(this);
                if(encryptedExport){if(exportPassword==null)throw new Exception("Missing password");json=CryptoBackup.encrypt(json,exportPassword);}
                if(exportPassword!=null){Arrays.fill(exportPassword,'\0');exportPassword=null;}encryptedExport=false;
                try(OutputStream out=getContentResolver().openOutputStream(data.getData(),"wt")){
                    if(out==null)throw new Exception("No output");out.write(json.getBytes(StandardCharsets.UTF_8));out.flush();
                }
                toast(R.string.exported);
            }else if(code==IMPORT){
                ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int n;
                try(InputStream in=getContentResolver().openInputStream(data.getData())){
                    if(in==null)throw new Exception("No input");while((n=in.read(buffer))!=-1){
                        if(bytes.size()+n>4*1024*1024)throw new Exception("Backup too big");bytes.write(buffer,0,n);
                    }
                }
                String raw=new String(bytes.toByteArray(),StandardCharsets.UTF_8);
                if(CryptoBackup.isEncrypted(raw)){
                    EditText password=inputLine("",getString(R.string.password_hint));password.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    new AlertDialog.Builder(this).setTitle(R.string.password_hint).setView(password)
                      .setPositiveButton(R.string.import_backup,(dlg,which)->{
                          char[] secret=password.getText().toString().toCharArray();
                          try{confirmImport(CryptoBackup.decrypt(raw,secret));}catch(Exception e){toast(R.string.bad_import);}
                          finally{Arrays.fill(secret,'\0');}
                      }).setNegativeButton(R.string.cancel,null).show();
                }else confirmImport(raw);
            }
        }catch(Exception e){toast(code==EXPORT?R.string.backup_error:R.string.bad_import);}
        finally{if(code==EXPORT){if(exportPassword!=null){Arrays.fill(exportPassword,'\0');exportPassword=null;}encryptedExport=false;}}
    }
    private void confirmImport(String raw){
        new AlertDialog.Builder(this).setMessage(R.string.import_confirm)
            .setPositiveButton(R.string.import_backup,(dlg,which)->{
                try{int count=TaskStore.importBackup(this,raw);
                    Toast.makeText(this,getString(R.string.import_summary,count),Toast.LENGTH_LONG).show();refresh();}
                catch(Exception e){toast(R.string.bad_import);}
            }).setNegativeButton(R.string.cancel,null).show();
    }
}
