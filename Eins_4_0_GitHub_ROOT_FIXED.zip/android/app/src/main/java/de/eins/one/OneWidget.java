package de.eins.one;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.widget.RemoteViews;
import java.util.List;
import java.util.Locale;

/** Three native widget sizes: single next action, next three, and day plan (five). */
public class OneWidget extends AppWidgetProvider {
    private static Context localized(Context c){String code=TaskStore.language(c);if("system".equals(code))return c;
        Configuration configuration=new Configuration(c.getResources().getConfiguration());configuration.setLocale(Locale.forLanguageTag(code));
        return c.createConfigurationContext(configuration);}
    public static void refresh(Context c){AppWidgetManager manager=AppWidgetManager.getInstance(c);
        for(Class<?> cls:new Class<?>[]{OneWidget.class,MediumWidget.class,LargeWidget.class}){
            int[] ids=manager.getAppWidgetIds(new ComponentName(c,cls));if(ids.length>0)update(c,manager,ids,cls);
        }
    }
    private static void update(Context c,AppWidgetManager manager,int[] ids,Class<?> cls){
        Context locale=localized(c);List<TaskStore.Task> open=TaskStore.sortedOpen(c);
        if(cls==LargeWidget.class){List<TaskStore.Task> todays=new java.util.ArrayList<>();
            for(TaskStore.Task t:open)if(TaskStore.bucket(t)<=1)todays.add(t);open=todays;}
        TaskStore.Task first=open.isEmpty()?null:open.get(0);
        int layout=cls==LargeWidget.class?R.layout.widget_large:cls==MediumWidget.class?R.layout.widget_medium:R.layout.widget_one;
        for(int id:ids){RemoteViews v=new RemoteViews(c.getPackageName(),layout);
            v.setTextViewText(R.id.widget_title,locale.getString(R.string.app_name));
            v.setTextViewText(R.id.widget_task,first==null?locale.getString(R.string.widget_empty):first.text);
            v.setTextViewText(R.id.widget_count,locale.getString(R.string.widget_count,open.size()));
            v.setTextViewText(R.id.widget_add,"+");v.setTextViewText(R.id.widget_done,first==null?"":"✓");
            if(cls==MediumWidget.class||cls==LargeWidget.class){
                int[] lines={R.id.widget_task2,R.id.widget_task3};
                for(int j=0;j<lines.length;j++)v.setTextViewText(lines[j],open.size()>j+1?"• "+open.get(j+1).text:"");
            }
            if(cls==LargeWidget.class){int[] lines={R.id.widget_task4,R.id.widget_task5};
                for(int j=0;j<lines.length;j++)v.setTextViewText(lines[j],open.size()>j+3?"• "+open.get(j+3).text:"");
            }
            Intent openIntent=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent tap=PendingIntent.getActivity(c,id*3,openIntent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Intent plusIntent=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("focus_add",true);
            PendingIntent plus=PendingIntent.getActivity(c,id*3+1,plusIntent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            v.setOnClickPendingIntent(R.id.widget_root,tap);v.setOnClickPendingIntent(R.id.widget_task,tap);v.setOnClickPendingIntent(R.id.widget_add,plus);
            if(first!=null){Intent complete=new Intent(c,CompleteReceiver.class).setAction(CompleteReceiver.ACTION_COMPLETE)
                .setData(Uri.parse("eins://widget/complete/"+Uri.encode(first.id))).putExtra("task_id",first.id);
                PendingIntent done=PendingIntent.getBroadcast(c,id*3+2,complete,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                v.setOnClickPendingIntent(R.id.widget_done,done);
            }else v.setOnClickPendingIntent(R.id.widget_done,tap);
            manager.updateAppWidget(id,v);
        }
    }
    @Override public void onUpdate(Context c,AppWidgetManager manager,int[] ids){update(c,manager,ids,getClass());}
    @Override public void onEnabled(Context c){refresh(c);}
}
