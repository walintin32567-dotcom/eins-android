package de.eins.one;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public final class ReminderReceiver extends BroadcastReceiver {
    public static final String ACTION_REMIND="de.eins.one.REMIND", ACTION_SNOOZE="de.eins.one.SNOOZE";
    static int notificationId(String id){return id.hashCode()&0x7fffffff;}
    @Override public void onReceive(Context c,Intent i){
        String id=i.getStringExtra("task_id");if(id==null||!id.matches("[A-Za-z0-9_-]{1,100}"))return;
        if(ACTION_SNOOZE.equals(i.getAction())){
            ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(notificationId(id));
            ReminderScheduler.snooze(c,id);return;
        }
        if(!ACTION_REMIND.equals(i.getAction())||!ReminderScheduler.notificationsAllowed(c))return;
        TaskStore.Task task=null;for(TaskStore.Task t:TaskStore.read(c).tasks)if(t.id.equals(id)&&!t.done){task=t;break;}
        if(task==null)return;
        ReminderScheduler.channel(c);
        ReminderScheduler.markDelivered(c,task);
        Intent open=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent view=PendingIntent.getActivity(c,notificationId(id),open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Intent snooze=new Intent(c,ReminderReceiver.class).setAction(ACTION_SNOOZE).setData(Uri.parse("eins://snooze/"+id)).putExtra("task_id",id);
        PendingIntent later=PendingIntent.getBroadcast(c,0,snooze,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Intent complete=new Intent(c,CompleteReceiver.class).setAction(CompleteReceiver.ACTION_COMPLETE)
           .setData(Uri.parse("eins://complete/"+id)).putExtra("task_id",id);
        PendingIntent done=PendingIntent.getBroadcast(c,0,complete,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n=new Notification.Builder(c,ReminderScheduler.CHANNEL).setSmallIcon(R.drawable.ic_notification)
          .setContentTitle(c.getString(R.string.reminder_title)).setContentText(task.text).setStyle(new Notification.BigTextStyle().bigText(task.text))
          .setAutoCancel(true).setVisibility(Notification.VISIBILITY_PRIVATE).setContentIntent(view).setCategory(Notification.CATEGORY_REMINDER)
          .addAction(new Notification.Action.Builder(null,c.getString(R.string.snooze_ten),later).build())
          .addAction(new Notification.Action.Builder(null,c.getString(R.string.done),done).build()).build();
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(notificationId(id),n);
    }
}
