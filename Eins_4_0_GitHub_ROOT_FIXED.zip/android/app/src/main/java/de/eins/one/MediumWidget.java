package de.eins.one;
public final class MediumWidget extends OneWidget {}
