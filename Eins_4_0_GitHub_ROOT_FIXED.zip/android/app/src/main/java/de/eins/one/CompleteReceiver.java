package de.eins.one;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Not exported: only our PendingIntent can trigger completion from home screen. */
public final class CompleteReceiver extends BroadcastReceiver {
    public static final String ACTION_COMPLETE="de.eins.one.COMPLETE";
    @Override public void onReceive(Context c,Intent intent){
        if(!ACTION_COMPLETE.equals(intent.getAction()))return;
        String id=intent.getStringExtra("task_id");
        if(id!=null&&id.matches("[A-Za-z0-9_-]{1,100}")){
            // Do not revert an already completed task if a stale PendingIntent is delivered twice.
            for(TaskStore.Task t:TaskStore.read(c).tasks)if(t.id.equals(id)&&!t.done){TaskStore.toggle(c,id);break;}
        }
        android.app.NotificationManager m=(android.app.NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(m!=null&&id!=null)m.cancel(ReminderReceiver.notificationId(id));
        OneWidget.refresh(c);
    }
}
