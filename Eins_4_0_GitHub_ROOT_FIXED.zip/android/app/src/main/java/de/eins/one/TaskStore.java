package de.eins.one;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Offline, transactional native store. Backup schema interoperates with web versions 1–3. */
public final class TaskStore {
    private static final String PREF = "tasks_private", KEY = "tasks", LANG = "preferred_language";
    public static final int LIMIT = 2500;
    private TaskStore() { }
    public static final class Task {
        public final String id, text, createdAt, updatedAt, completedAt, dueDate, dueTime, repeat;
        public final boolean done, priority;
        public Task(JSONObject o) throws JSONException {
            id = o.getString("id"); text=o.getString("text");
            createdAt=o.getString("createdAt"); updatedAt=o.getString("updatedAt");
            completedAt=o.isNull("completedAt")?null:o.optString("completedAt",null);
            dueDate=o.isNull("dueDate")?null:o.optString("dueDate",null);
            dueTime=o.isNull("dueTime")?null:o.optString("dueTime",null);
            done=o.optBoolean("done"); priority=o.optBoolean("priority"); repeat=o.optString("repeat","none");
        }
        public JSONObject json() throws JSONException {
            JSONObject o=new JSONObject();
            o.put("id",id);o.put("text",text);o.put("dueDate",dueDate==null?JSONObject.NULL:dueDate);
            o.put("dueTime",dueTime==null?JSONObject.NULL:dueTime);o.put("repeat",repeat);o.put("priority",priority);
            o.put("done",done);o.put("createdAt",createdAt);o.put("updatedAt",updatedAt);
            o.put("completedAt",completedAt==null?JSONObject.NULL:completedAt);return o;
        }
    }
    public static final class Read {
        public final List<Task> tasks;
        public final boolean corrupt;
        private Read(List<Task> t,boolean c){tasks=t;corrupt=c;}
    }
    private static SharedPreferences prefs(Context c){return c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    public static String language(Context c){return prefs(c).getString(LANG,"de");}
    public static boolean setLanguage(Context c,String code){return prefs(c).edit().putString(LANG,code).commit();}
    private static String stamp(){return Instant.now().toString();}
    private static boolean dateOk(String s){if(s==null)return true;try{LocalDate d=LocalDate.parse(s);return d.getYear()>=1970&&d.getYear()<=2100&&s.equals(d.toString());}catch(Exception e){return false;}}
    private static boolean timeOk(String s){if(s==null)return true;try{return s.matches("[0-2][0-9]:[0-5][0-9]")&&LocalTime.parse(s)!=null;}catch(Exception e){return false;}}
    private static Task parse(JSONObject o) throws JSONException {
        String id=o.optString("id", ""), text=o.optString("text", "").trim();
        if(!id.matches("[A-Za-z0-9_-]{1,100}")||text.isEmpty()||text.length()>180)throw new JSONException("Bad task id or text");
        String date=o.isNull("dueDate")?null:o.optString("dueDate",null);
        String time=o.isNull("dueTime")?null:o.optString("dueTime",null);
        if(!dateOk(date)||!timeOk(time)||(date==null&&time!=null))throw new JSONException("Invalid date/time");
        if(!o.has("repeat"))o.put("repeat","none");
        if(!java.util.Arrays.asList("none","daily","weekly","monthly").contains(o.optString("repeat")) || (date==null && !"none".equals(o.optString("repeat"))))throw new JSONException("Invalid recurrence");
        String c=o.optString("createdAt",""),u=o.optString("updatedAt","");
        if(c.isEmpty()||u.isEmpty())throw new JSONException("Missing timestamps");
        try{Instant.parse(c);Instant.parse(u);}catch(Exception e){throw new JSONException("Bad timestamp");}
        if(!o.isNull("completedAt")){try{Instant.parse(o.optString("completedAt"));}catch(Exception e){throw new JSONException("Bad completion timestamp");}}
        return new Task(o);
    }
    public static synchronized Read read(Context c){
        String json=prefs(c).getString(KEY,"[]");
        try{
            JSONArray arr=new JSONArray(json);if(arr.length()>LIMIT)throw new JSONException("Too many tasks");
            List<Task> tasks=new ArrayList<>();Set<String> ids=new HashSet<>();
            for(int i=0;i<arr.length();i++){
                Task t=parse(arr.getJSONObject(i));if(!ids.add(t.id))throw new JSONException("Duplicate ID");tasks.add(t);
            }
            return new Read(tasks,false);
        }catch(Exception e){return new Read(new ArrayList<>(),true);}
    }
    private static synchronized boolean commit(Context c,List<Task> tasks){
        if(tasks.size()>LIMIT)return false;
        JSONArray arr=new JSONArray();try{for(Task t:tasks)arr.put(t.json());}catch(JSONException e){return false;}
        boolean saved=prefs(c).edit().putString(KEY,arr.toString()).commit();
        if(saved){OneWidget.refresh(c);ReminderScheduler.sync(c);}return saved;
    }
    public static synchronized boolean add(Context c,String title,String date,String time,boolean important){return add(c,title,date,time,important,"none");}
    public static synchronized boolean add(Context c,String title,String date,String time,boolean important,String recurrence){
        Read r=read(c);String s=title.trim();if(r.corrupt||s.isEmpty()||s.length()>180||!dateOk(date)||!timeOk(time)||(date==null&&time!=null)||!java.util.Arrays.asList("none","daily","weekly","monthly").contains(recurrence)||(date==null&&!"none".equals(recurrence))||r.tasks.size()>=LIMIT)return false;
        String now=stamp();try{
            JSONObject o=new JSONObject().put("id",UUID.randomUUID().toString()).put("text",s)
                .put("dueDate",date==null?JSONObject.NULL:date).put("dueTime",time==null?JSONObject.NULL:time)
                .put("repeat",recurrence).put("priority",important).put("done",false).put("createdAt",now).put("updatedAt",now).put("completedAt",JSONObject.NULL);
            r.tasks.add(new Task(o));return commit(c,r.tasks);
        }catch(JSONException e){return false;}
    }
    public static synchronized boolean update(Context c,String id,String title,String date,String time,boolean important){return update(c,id,title,date,time,important,null);}
    public static synchronized boolean update(Context c,String id,String title,String date,String time,boolean important,String recurrence){
        Read r=read(c);if(r.corrupt||title.trim().isEmpty()||title.trim().length()>180||!dateOk(date)||!timeOk(time)||(date==null&&time!=null))return false;
        for(int i=0;i<r.tasks.size();i++)if(r.tasks.get(i).id.equals(id))try{
            JSONObject o=r.tasks.get(i).json();o.put("text",title.trim());o.put("dueDate",date==null?JSONObject.NULL:date);
            o.put("dueTime",time==null?JSONObject.NULL:time);if(recurrence!=null)o.put("repeat",recurrence);o.put("priority",important);o.put("updatedAt",stamp());
            if(!java.util.Arrays.asList("none","daily","weekly","monthly").contains(o.optString("repeat"))||(date==null&&!"none".equals(o.optString("repeat"))))return false;
            r.tasks.set(i,new Task(o));return commit(c,r.tasks);
        }catch(JSONException e){return false;}return false;
    }
    public static synchronized boolean toggle(Context c,String id){
        Read r=read(c);if(r.corrupt)return false;
        for(int i=0;i<r.tasks.size();i++)if(r.tasks.get(i).id.equals(id))try{
            JSONObject o=r.tasks.get(i).json();boolean done=!r.tasks.get(i).done;
            if(done && !"none".equals(r.tasks.get(i).repeat) && r.tasks.get(i).dueDate!=null){
                LocalDate next=Recurrence.next(LocalDate.parse(r.tasks.get(i).dueDate),LocalDate.now(),r.tasks.get(i).repeat);
                o.put("dueDate",next.toString()).put("done",false).put("completedAt",JSONObject.NULL);
            }else o.put("done",done).put("completedAt",done?stamp():JSONObject.NULL);
            o.put("updatedAt",stamp());
            r.tasks.set(i,new Task(o));return commit(c,r.tasks);
        }catch(JSONException e){return false;}return false;
    }
    public static synchronized boolean delete(Context c,String id){
        Read r=read(c);if(r.corrupt)return false;
        if(!r.tasks.removeIf(t->t.id.equals(id)))return false;
        return commit(c,r.tasks);
    }
    public static int bucket(Task t){if(t.dueDate==null)return 3;String today=LocalDate.now().toString();if(t.dueDate.compareTo(today)<0)return 0;return t.dueDate.equals(today)?1:2;}
    public static List<Task> sortedOpen(Context c){
        List<Task> list=new ArrayList<>();for(Task t:read(c).tasks)if(!t.done)list.add(t);
        Collections.sort(list,Comparator.comparingInt(TaskStore::bucket)
            .thenComparingInt(t->t.priority?0:1)
            .thenComparing(t->t.dueDate==null?"9999":t.dueDate)
            .thenComparing(t->t.dueTime==null?"00:00":t.dueTime)
            .thenComparing(t->t.createdAt));return list;
    }
    public static synchronized String backup(Context c) throws JSONException {
        Read r=read(c);if(r.corrupt)throw new JSONException("Corrupted store; never export blank over it");
        JSONArray arr=new JSONArray();for(Task t:r.tasks)arr.put(t.json());
        return new JSONObject().put("app","one-simple-offline").put("schemaVersion",1)
            .put("exportedAt",stamp()).put("tasks",arr).toString(2);
    }
    public static synchronized int importBackup(Context c,String text) throws JSONException {
        if(text==null||text.length()>2*1024*1024)throw new JSONException("Too large");
        JSONObject backup=new JSONObject(text);if(!"one-simple-offline".equals(backup.optString("app"))||backup.optInt("schemaVersion",-1)!=1)
            throw new JSONException("Wrong backup format");
        JSONArray source=backup.getJSONArray("tasks");if(source.length()>LIMIT)throw new JSONException("Too many incoming tasks");
        Read r=read(c);if(r.corrupt)r=new Read(new ArrayList<>(),false); // Recovery from a corrupt store replaces it only after UI confirmation.
        Set<String> seen=new HashSet<>();for(Task t:r.tasks)seen.add(t.id);
        int added=0;for(int i=0;i<source.length();i++){
            Task t=parse(source.getJSONObject(i));if(seen.add(t.id)){r.tasks.add(t);added++;}
        }
        if(r.tasks.size()>LIMIT)throw new JSONException("Too many merged tasks");
        if(added>0&&!commit(c,r.tasks))throw new JSONException("Storage commit failed");return added;
    }
}
