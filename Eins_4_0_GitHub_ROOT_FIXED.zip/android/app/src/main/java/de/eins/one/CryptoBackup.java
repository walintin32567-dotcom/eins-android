package de.eins.one;

import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/** Optional authenticated password-protected backups. No keys or passwords are stored. */
public final class CryptoBackup {
    private CryptoBackup(){}
    private static final SecureRandom RNG=new SecureRandom();
    private static SecretKeySpec derive(char[] password,byte[] salt) throws Exception {
        PBEKeySpec spec=new PBEKeySpec(password,salt,210000,256);
        try{return new SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(),"AES");}
        finally{spec.clearPassword();}
    }
    public static String encrypt(String plain,char[] password) throws Exception {
        if(password==null||password.length<8)throw new IllegalArgumentException("Password at least 8 chars");
        byte[] salt=new byte[16],iv=new byte[12];RNG.nextBytes(salt);RNG.nextBytes(iv);
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,derive(password,salt),new GCMParameterSpec(128,iv));
        byte[] data=cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        return new JSONObject().put("app","eins-encrypted").put("schemaVersion",1).put("iterations",210000)
            .put("salt",Base64.getEncoder().encodeToString(salt)).put("iv",Base64.getEncoder().encodeToString(iv))
            .put("data",Base64.getEncoder().encodeToString(data)).toString(2);
    }
    public static boolean isEncrypted(String payload){try{return "eins-encrypted".equals(new JSONObject(payload).optString("app"));}catch(Exception e){return false;}}
    public static String decrypt(String payload,char[] password) throws Exception {
        JSONObject json=new JSONObject(payload);
        if(!"eins-encrypted".equals(json.getString("app"))||json.getInt("schemaVersion")!=1||json.getInt("iterations")!=210000)throw new IllegalArgumentException("Wrong schema");
        byte[] salt=Base64.getDecoder().decode(json.getString("salt")),iv=Base64.getDecoder().decode(json.getString("iv")),data=Base64.getDecoder().decode(json.getString("data"));
        if(salt.length!=16||iv.length!=12||data.length>2*1024*1024+16)throw new IllegalArgumentException("Invalid encrypted payload");
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,derive(password,salt),new GCMParameterSpec(128,iv));
        return new String(cipher.doFinal(data),StandardCharsets.UTF_8);
    }
}
