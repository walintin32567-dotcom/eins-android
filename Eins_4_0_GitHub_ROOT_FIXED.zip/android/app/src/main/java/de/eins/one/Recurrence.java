package de.eins.one;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
/** Preserves original month-day anchor (Jan 31 -> Feb 28 -> Mar 31) without drift. */
public final class Recurrence {
    private Recurrence(){}
    public static LocalDate next(LocalDate due,LocalDate completed,String repeat){
        if(due==null||completed==null)return null;
        long n;
        switch(repeat){
            case "daily":n=Math.max(1,ChronoUnit.DAYS.between(due,completed)+1);break;
            case "weekly":n=Math.max(1,ChronoUnit.WEEKS.between(due,completed)+1);break;
            case "monthly":n=Math.max(1,ChronoUnit.MONTHS.between(due,completed)+1);break;
            default:return null;
        }
        LocalDate candidate;
        do{switch(repeat){
            case "daily":candidate=due.plusDays(n);break;
            case "weekly":candidate=due.plusWeeks(n);break;
            default:candidate=due.plusMonths(n);
        }n++;}while(!candidate.isAfter(completed));
        return candidate;
    }
}
