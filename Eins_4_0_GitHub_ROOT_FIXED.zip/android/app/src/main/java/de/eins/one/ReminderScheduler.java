package de.eins.one;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import android.net.Uri;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.HashSet;
import java.util.Set;

/** Entirely local alarms. Exact scheduling when specifically authorized, inexact otherwise. */
public final class ReminderScheduler {
    private static final String PREF="alarm_registry",KEY="scheduled_ids",DELIVERED="delivered_keys";
    public static final String CHANNEL="eins_reminders";
    private ReminderScheduler(){}
    public static void channel(Context c){
        NotificationManager n=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(n!=null){NotificationChannel ch=new NotificationChannel(CHANNEL,c.getString(R.string.reminders),NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription(c.getString(R.string.reminders_description));n.createNotificationChannel(ch);}
    }
    public static boolean notificationsAllowed(Context c){return Build.VERSION.SDK_INT<33||c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;}
    public static boolean preciseAllowed(Context c){AlarmManager alarm=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        return alarm!=null&&(Build.VERSION.SDK_INT<31||alarm.canScheduleExactAlarms());}
    private static PendingIntent pending(Context c,String id){
        Intent intent=new Intent(c,ReminderReceiver.class).setAction(ReminderReceiver.ACTION_REMIND)
           .setData(Uri.parse("eins://reminder/"+Uri.encode(id))).putExtra("task_id",id);
        return PendingIntent.getBroadcast(c,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    public static synchronized void sync(Context c){
        AlarmManager mgr=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(mgr==null)return;
        TaskStore.Read read=TaskStore.read(c);
        if(read.corrupt)return; // Never disturb alarms if store is corrupt.
        Set<String> previous=new HashSet<>(c.getSharedPreferences(PREF,0).getStringSet(KEY,new HashSet<>()));
        for(String id:previous)mgr.cancel(pending(c,id));
        Set<String> fresh=new HashSet<>();
        channel(c);
        for(TaskStore.Task t:read.tasks){
            if(t.done||t.dueDate==null||t.dueTime==null){c.getSharedPreferences(PREF,0).edit().remove("snooze_"+t.id).apply();continue;}
            long snoozed=c.getSharedPreferences(PREF,0).getLong("snooze_"+t.id,0);
            if(snoozed>System.currentTimeMillis()){
                schedule(mgr,pending(c,t.id),snoozed);fresh.add(t.id);continue;
            }
            if(snoozed!=0)c.getSharedPreferences(PREF,0).edit().remove("snooze_"+t.id).apply();
            try{long at=LocalDateTime.parse(t.dueDate+"T"+t.dueTime).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
                if(at<=System.currentTimeMillis()){
                    // Deliver once after reboot / clock changes if overdue less than 24h.
                    String key=t.id+"@"+t.dueDate+"T"+t.dueTime;
                    if(System.currentTimeMillis()-at>24*60*60*1000L||
                       c.getSharedPreferences(PREF,0).getStringSet(DELIVERED,new HashSet<>()).contains(key))continue;
                    at=System.currentTimeMillis()+10000;
                }
                schedule(mgr,pending(c,t.id),at);fresh.add(t.id);
            }catch(Exception ignored){}
        }
        c.getSharedPreferences(PREF,0).edit().putStringSet(KEY,fresh).commit();
    }
    private static void schedule(AlarmManager mgr,PendingIntent pi,long at){
        try{if(Build.VERSION.SDK_INT<31||mgr.canScheduleExactAlarms())mgr.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
            else mgr.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
        }catch(SecurityException denied){mgr.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);}
    }
    public static synchronized void markDelivered(Context c,TaskStore.Task t){
        Set<String> keys=new HashSet<>(c.getSharedPreferences(PREF,0).getStringSet(DELIVERED,new HashSet<>()));
        if(keys.size()>3000)keys.clear();
        keys.add(t.id+"@"+t.dueDate+"T"+t.dueTime);
        c.getSharedPreferences(PREF,0).edit().putStringSet(DELIVERED,keys).remove("snooze_"+t.id).commit();
    }
    public static synchronized void snooze(Context c,String id){
        TaskStore.Task found=null;for(TaskStore.Task t:TaskStore.read(c).tasks)if(t.id.equals(id)&&!t.done){found=t;break;}
        if(found==null)return;
        AlarmManager mgr=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(mgr==null)return;
        schedule(mgr,pending(c,id),System.currentTimeMillis()+10*60*1000L);
        Set<String> ids=new HashSet<>(c.getSharedPreferences(PREF,0).getStringSet(KEY,new HashSet<>()));ids.add(id);
        c.getSharedPreferences(PREF,0).edit().putStringSet(KEY,ids).putLong("snooze_"+id,System.currentTimeMillis()+10*60*1000L).commit();
    }
}
