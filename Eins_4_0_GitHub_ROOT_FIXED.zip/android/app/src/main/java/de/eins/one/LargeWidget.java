package de.eins.one;
public final class LargeWidget extends OneWidget {}
