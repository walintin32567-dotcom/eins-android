import json,subprocess,re
from pathlib import Path
from xml.sax.saxutils import escape
root=Path('/mnt/data/odne_v3/android/app/src/main/res')
js=Path('/mnt/data/odne_v3/web/index.html')
script=r'''const fs=require('fs'),vm=require('vm');let h=fs.readFileSync(process.argv[1],'utf8');let src=h.split('const DICT=')[1].split('\nconst $=')[0];let obj=vm.runInNewContext('const DICT='+src+'\nDICT');console.log(JSON.stringify(obj));'''
dicts=json.loads(subprocess.check_output(['node','-e',script,str(js)]))
fields={
'app_name':'brand','headline':'captureLabel','capture_label':'captureLabel','placeholder':'placeholder',
'add':'add','today':'today','tomorrow':'tomorrow','anytime':'anytime','choose_date':'chooseDate',
'next':'next','later':'tabLater','all':'tabAll','done':'tabDone','backup':'backup',
'export_backup':'exportBackup','import_backup':'importBackup','settings':'settings','important':'important',
'cancel':'cancel','save':'save','delete':'delete','data_info':'dataInfo','not_saved':'notSaved',
'no_tasks':'noTasks','widget_empty':'nothingNext','choose_valid_date':'chooseValidDate','edit_task':'editTask',
'language':'languageLabel','exported':'exported','bad_import':'badImport','date_optional':'dateOptional',
'time_optional':'timeOptional','no_date':'noDate','overdue':'overdue','done_toast':'doneToast',
'added_toast':'addedToast','saved_toast':'savedToast','backup_error':'backupError','delete_confirm':'deleteConfirm',
'task_text':'taskText','priority':'priority','privacy':'privacy','empty_list':'emptyAll','date_hint':'dateOptional','time_hint':'timeOptional'
}
extra={
'de':dict(widget_name='Eins. – nächste Aufgabe',widget_description='Zeigt die nächste Aufgabe mit Hinzufügen und Erledigen.',widget_add='Aufgabe hinzufügen',widget_complete='Aufgabe erledigen',widget_count='%1$d offen',tasks_count='%1$d offene Aufgaben',system_language='Systemsprache',store_corrupt='Gespeicherte Daten beschädigt. Bitte App-Daten nicht löschen; Sicherung wiederherstellen.',import_confirm='Sicherung importieren? Vorhandene Aufgaben bleiben erhalten.',import_summary='%1$d Aufgaben hinzugefügt.',empty_list='Hier gibt es noch keine Aufgaben.',date_hint='Datum: JJJJ-MM-TT (optional)',time_hint='Uhrzeit: HH:MM (optional)'),
'en':dict(widget_name='One. – next task',widget_description='Next task with quick add and complete.',widget_add='Add task',widget_complete='Complete task',widget_count='%1$d open',tasks_count='%1$d open tasks',system_language='System language',store_corrupt='Stored data is damaged. Do not clear app data; restore a backup.',import_confirm='Import backup? Existing tasks remain.',import_summary='%1$d tasks added.',empty_list='No tasks here yet.',date_hint='Date: YYYY-MM-DD (optional)',time_hint='Time: HH:MM (optional)'),
'uk':dict(widget_name='Одне. – наступна справа',widget_description='Наступна справа, швидке додавання і виконання.',widget_add='Додати справу',widget_complete='Завершити справу',widget_count='%1$d відкритих',tasks_count='%1$d активних справ',system_language='Мова системи',store_corrupt='Збережені дані пошкоджено. Не очищай пам’ять застосунку; віднови копію.',import_confirm='Імпортувати копію? Наявні справи залишаться.',import_summary='Додано справ: %1$d.',empty_list='Тут поки що немає справ.',date_hint='Дата: РРРР-ММ-ДД (необов’язково)',time_hint='Час: ГГ:ХХ (необов’язково)'),
'tr':dict(widget_name='Bir. – sıradaki görev',widget_description='Sıradaki görev, hızlı ekleme ve tamamlama.',widget_add='Görev ekle',widget_complete='Görevi tamamla',widget_count='%1$d açık',tasks_count='%1$d açık görev',system_language='Sistem dili',store_corrupt='Kayıtlı veriler hasarlı. Uygulama verilerini silme; yedeği geri yükle.',import_confirm='Yedek içe aktarılsın mı? Var olan görevler korunur.',import_summary='%1$d görev eklendi.',empty_list='Burada henüz görev yok.',date_hint='Tarih: YYYY-MM-DD (isteğe bağlı)',time_hint='Saat: HH:MM (isteğe bağlı)'),
'ar':dict(widget_name='واحد. – المهمة التالية',widget_description='مهمتك التالية مع الإضافة والإكمال السريع.',widget_add='إضافة مهمة',widget_complete='إكمال المهمة',widget_count='%1$d مفتوحة',tasks_count='%1$d مهام مفتوحة',system_language='لغة النظام',store_corrupt='البيانات المحفوظة تالفة. لا تمسح بيانات التطبيق؛ استعد نسخة احتياطية.',import_confirm='استيراد النسخة؟ ستبقى المهام الموجودة.',import_summary='أُضيفت %1$d مهمة.',empty_list='لا مهام هنا بعد.',date_hint='التاريخ: YYYY-MM-DD (اختياري)',time_hint='الوقت: HH:MM (اختياري)'),
'pl':dict(widget_name='Jedno. – następna rzecz',widget_description='Następne zadanie z dodawaniem i kończeniem.',widget_add='Dodaj zadanie',widget_complete='Zakończ zadanie',widget_count='%1$d otwartych',tasks_count='%1$d otwartych zadań',system_language='Język systemu',store_corrupt='Dane są uszkodzone. Nie usuwaj danych aplikacji; przywróć kopię.',import_confirm='Zaimportować kopię? Obecne zadania zostaną.',import_summary='Dodano %1$d zadań.',empty_list='Brak zadań.',date_hint='Data: RRRR-MM-DD (opcjonalnie)',time_hint='Godzina: GG:MM (opcjonalnie)'),
'ro':dict(widget_name='Unu. – următoarea sarcină',widget_description='Următoarea sarcină cu adăugare și finalizare rapidă.',widget_add='Adaugă sarcină',widget_complete='Finalizează sarcina',widget_count='%1$d deschise',tasks_count='%1$d sarcini deschise',system_language='Limba sistemului',store_corrupt='Datele sunt deteriorate. Nu șterge datele aplicației; restaurează copia.',import_confirm='Importăm copia? Sarcinile existente rămân.',import_summary='%1$d sarcini adăugate.',empty_list='Încă nu sunt sarcini.',date_hint='Dată: AAAA-LL-ZZ (opțional)',time_hint='Ora: HH:MM (opțional)'),
'it':dict(widget_name='Uno. – prossima attività',widget_description='La prossima attività con aggiunta e completamento rapidi.',widget_add='Aggiungi attività',widget_complete='Completa attività',widget_count='%1$d aperte',tasks_count='%1$d attività aperte',system_language='Lingua di sistema',store_corrupt='Dati danneggiati. Non cancellare i dati dell’app; ripristina un backup.',import_confirm='Importare il backup? Le attività esistenti resteranno.',import_summary='%1$d attività aggiunte.',empty_list='Non ci sono attività.',date_hint='Data: AAAA-MM-GG (facoltativa)',time_hint='Ora: HH:MM (facoltativa)'),
'fr':dict(widget_name='Une. – prochaine tâche',widget_description='Prochaine tâche avec ajout et validation rapides.',widget_add='Ajouter une tâche',widget_complete='Terminer la tâche',widget_count='%1$d en cours',tasks_count='%1$d tâches en cours',system_language='Langue du système',store_corrupt='Données endommagées. N’efface pas les données de l’appli; restaure une sauvegarde.',import_confirm='Importer la sauvegarde ? Les tâches existantes restent.',import_summary='%1$d tâches ajoutées.',empty_list='Aucune tâche ici.',date_hint='Date : AAAA-MM-JJ (facultative)',time_hint='Heure : HH:MM (facultative)'),
'es':dict(widget_name='Uno. – siguiente tarea',widget_description='Siguiente tarea, añadir y completar rápidamente.',widget_add='Añadir tarea',widget_complete='Completar tarea',widget_count='%1$d abiertas',tasks_count='%1$d tareas abiertas',system_language='Idioma del sistema',store_corrupt='Datos dañados. No borres los datos de la app; restaura una copia.',import_confirm='¿Importar copia? Las tareas existentes se conservan.',import_summary='%1$d tareas añadidas.',empty_list='Todavía no hay tareas aquí.',date_hint='Fecha: AAAA-MM-DD (opcional)',time_hint='Hora: HH:MM (opcional)')}
for lang,d in dicts.items():
 strings={name:d[key] for name,key in fields.items()}
 strings.update(extra[lang]);strings['headline']=d['headline'].replace('<br>',' ')
 # Android strings XML and AAPT both need single quotes escaped in string resources.
 dest=root/('values' if lang=='de' else 'values-'+lang);dest.mkdir(parents=True,exist_ok=True)
 lines=['<?xml version="1.0" encoding="utf-8"?>','<resources>']
 for k,v in sorted(strings.items()):
  assert isinstance(v,str),(lang,k)
  # AAPT apostrophes must be backslash escaped, and leading @/? must not become resource refs.
  esc=escape(v).replace("'",r"\'").replace('\\','\\')
  lines.append(f'    <string name="{k}">{esc}</string>')
 lines.append('</resources>')
 (dest/'strings.xml').write_text('\n'.join(lines)+'\n')
 print(lang,len(strings))
