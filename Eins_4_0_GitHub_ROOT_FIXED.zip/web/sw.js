/* Static, same-origin, app-shell-only offline cache. No personal task data is cached. */
const VERSION = 'one-offline-v3';
const SHELL = ['./', './index.html', './manifest.webmanifest', './icons/icon-192.png', './icons/icon-512.png'];
const scope = new URL(self.registration.scope);
const rootPath = scope.pathname;
const indexPath = new URL('./index.html', scope).pathname;
const staticPaths = new Set(['./manifest.webmanifest', './icons/icon-192.png', './icons/icon-512.png'].map(path => new URL(path, scope).pathname));

self.addEventListener('install', event => {
  event.waitUntil(caches.open(VERSION).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(key => key.startsWith('one-offline-') && key !== VERSION).map(key => caches.delete(key))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== scope.origin) return;
  const isAppPage = url.pathname === rootPath || url.pathname === indexPath;
  if (!isAppPage && !staticPaths.has(url.pathname)) return;
  event.respondWith((async () => {
    const cache = await caches.open(VERSION);
    if (isAppPage) {
      try {
        const response = await fetch(request);
        if (response.ok) await cache.put('./index.html', response.clone());
        return response;
      } catch (error) {
        return (await cache.match('./index.html')) || Response.error();
      }
    }
    const canonical = new URL(url.pathname, scope.origin);
    const cached = await cache.match(canonical.href);
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response.ok) await cache.put(canonical.href, response.clone());
      return response;
    } catch (error) {
      return Response.error();
    }
  })());
});
