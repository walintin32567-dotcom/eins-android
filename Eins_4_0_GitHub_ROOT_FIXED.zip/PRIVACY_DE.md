# Datenschutz – Eins. (Entwurf, Stand 17.09.2026)

Eins. ist eine offline nutzbare Aufgaben-App. Aufgaben, Termine, Erinnerungszeiten und Einstellungen werden lokal auf Ihrem Android-Gerät gespeichert. Die App selbst verfügt über keine Internetberechtigung, keinen Nutzeraccount, keine Werbung und keine Analytics-SDKs. Sie sendet keine Aufgabeninhalte an einen Server des App-Anbieters.

Für Erinnerungen kann die App die Android-Benachrichtigungsberechtigung benötigen. Genaue Erinnerungen erfordern gegebenenfalls einen zusätzlichen Android-Systemzugriff. Für die optionale Spracheingabe wird nach Zustimmung das Mikrofon verwendet; die Funktion erscheint nur bei auf dem Gerät verfügbarer Offline-Spracherkennung. Bitte beachten Sie, dass die Android-Spracherkennungsfunktion ein Systemdienst des Geräteherstellers bzw. des installierten Erkennungsanbieters ist; dessen Datenschutzbedingungen sind gesondert zu prüfen.

Sie können Ihre Aufgaben über die Android-Dateiauswahl exportieren. Eine optionale passwortgeschützte Sicherung verwendet AES-GCM und PBKDF2. Die Wahl des Speicherorts und eine freiwillige Weitergabe der exportierten Datei liegen bei Ihnen. Die App legt keine Kopien in einer eigenen Cloud an. Beim Deinstallieren oder Löschen der App-Daten können Aufgaben verloren gehen. Android-Systembackups sind für diese App deaktiviert.

Der Google Play Store verarbeitet Käufe, Downloads und gegebenenfalls Abrechnungsdaten nach seinen eigenen Bedingungen; das geschieht nicht durch die Offline-Funktion der App.

**Vor Veröffentlichung ergänzen:** Name, ladungsfähige Anschrift und Kontakt des Verantwortlichen; erreichbare E-Mail; Rechtsgrundlagen und weitere gesetzlich erforderliche Angaben; tatsächliches Verhalten der finalen APK/AAB und des jeweiligen On-Device-Sprachanbieters; finale Play-Data-safety-Deklaration. Dieser Entwurf ist keine abgeschlossene Rechtsprüfung.
