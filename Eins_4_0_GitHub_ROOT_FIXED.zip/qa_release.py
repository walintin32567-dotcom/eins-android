from pathlib import Path
import xml.etree.ElementTree as ET
import re,subprocess,zipfile
R=Path(__file__).parent; root=R/'android/app/src/main'; source=root/'java/de/eins/one'; res=root/'res'
results=[]
def check(name,condition):
    results.append((name,bool(condition)))
    if not condition: print('FAIL',name)
manifest=ET.parse(root/'AndroidManifest.xml').getroot(); andr='{http://schemas.android.com/apk/res/android}'
perms={e.get(andr+'name') for e in manifest.findall('uses-permission')}
check('No INTERNET access declared','android.permission.INTERNET' not in perms)
check('Reminders and microphone permissions are explicit',{'android.permission.RECEIVE_BOOT_COMPLETED','android.permission.POST_NOTIFICATIONS','android.permission.RECORD_AUDIO','android.permission.SCHEDULE_EXACT_ALARM'}<=perms)
app=manifest.find('application')
check('Cloud backup disabled',app.get(andr+'allowBackup')=='false')
widgets={e.get(andr+'name') for e in app.findall('receiver') if e.find("meta-data[@"+andr+"name='android.appwidget.provider']") is not None}
check('Three real Android widget providers',widgets=={'.OneWidget','.MediumWidget','.LargeWidget'})
check('Reminder + boot receivers declared',{'.ReminderReceiver','.RescheduleReceiver','.CompleteReceiver'}<={e.get(andr+'name') for e in app.findall('receiver')})
check('Boot and permission-change reschedule actions',{'android.intent.action.BOOT_COMPLETED','android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED'}<=set(e.get(andr+'name') for rec in app.findall('receiver') for e in rec.findall('intent-filter/action')))
xmls=list(res.rglob('*.xml'))
for xml in xmls:ET.parse(xml)
check('Every Android XML parses',len(xmls)>=20)
locales=['de','en','uk','tr','ar','pl','ro','it','fr','es']
base=root/'res/values/strings.xml'
strings={e.get('name') for e in ET.parse(base).getroot().findall('string')}
check('German base contains all new feature strings',{'voice','repeat_monthly','smart_confirm','export_encrypted','widget_large_name'}<=strings)
for loc in locales[1:]:
 p=res/f'values-{loc}/strings.xml'; keys={e.get('name') for e in ET.parse(p).getroot().findall('string')}
 check(f'{loc} translation covers Android UI',strings<=keys)
check('Arabic uses RTL app capability',app.get(andr+'supportsRtl')=='true')
refs=set()
for file in source.glob('*.java'):refs|=set(re.findall(r'R\.string\.([A-Za-z_0-9]+)',file.read_text()))
check('All Java string references resolve',refs<=strings)
layouts={p.stem for p in (res/'layout').glob('*.xml')}
lrefs=set()
for file in source.glob('*.java'):lrefs|=set(re.findall(r'(?<!android\.)R\.layout\.([A-Za-z_0-9]+)',file.read_text()))
check('All Java layout references resolve',lrefs<=layouts)
ids={e.attrib.get(andr+'id','').removeprefix('@+id/') for xml in (res/'layout').glob('*.xml') for e in ET.parse(xml).getroot().iter()}
irefs=set()
for file in source.glob('*.java'):irefs|=set(re.findall(r'R\.id\.([A-Za-z_0-9]+)',file.read_text()))
check('All Java view IDs resolve',irefs<=ids)
check('Each widget has its own XML layout',{'widget_one','widget_medium','widget_large'}<=layouts)
check('Three provider metadata configurations',all((res/'xml'/f'{p}_widget_info.xml').exists() for p in ('one','medium','large')))
code='\n'.join(p.read_text() for p in source.glob('*.java'))
check('Offline speech explicitly on device','createOnDeviceSpeechRecognizer' in code and 'isOnDeviceRecognitionAvailable' in code)
check('Local alarm scheduler has inexact fallback','setAndAllowWhileIdle' in code and 'setExactAndAllowWhileIdle' in code)
check('Notifications support snoozing and done','ACTION_SNOOZE' in code and 'ACTION_COMPLETE' in code)
check('Monthly repeat anchor tested with Java source',(source/'Recurrence.java').exists() and 'due.plusMonths(n)' in code)
check('Encrypted backup uses AES-GCM and PBKDF2', 'AES/GCM/NoPadding' in code and 'PBKDF2WithHmacSHA256' in code)
check('Secure backup uses random IV and salt','RNG.nextBytes(salt)' in code and 'RNG.nextBytes(iv)' in code)
check('No third-party ads, tracking or cloud libraries',not re.search(r'com\.google\.firebase|com\.google\.android\.gms\.ads|okhttp|retrofit',code,re.I))
check('Smart suggestions require confirmation','setTitle(R.string.smart_confirm)' in code and 'setNeutralButton(R.string.save_original,' in code)
check('Data writes check durable commit','edit().putString(KEY,arr.toString()).commit()' in code)
check('Android minimum API 26 and targets 36','minSdk 26' in (R/'android/app/build.gradle').read_text() and 'targetSdk 36' in (R/'android/app/build.gradle').read_text())
check('Web preview supplied separately',(R/'web/index.html').exists() and (R/'web/sw.js').exists())
count=sum(ok for _,ok in results)
for name,passed in results:print(('PASS' if passed else 'FAIL')+' '+name)
print(f'RESULT: {count}/{len(results)} static Android/offline/translation checks')
if count<len(results):raise SystemExit(1)
